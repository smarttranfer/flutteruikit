import 'package:flutter/material.dart';

enum BottomBarPages { Home, CategorySelection }

class Constants {
  static final Color primaryColor = Color.fromRGBO(251, 89, 84, 1);
}
