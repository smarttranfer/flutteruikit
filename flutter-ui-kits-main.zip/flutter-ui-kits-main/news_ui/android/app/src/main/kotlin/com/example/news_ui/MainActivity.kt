package com.example.news_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
