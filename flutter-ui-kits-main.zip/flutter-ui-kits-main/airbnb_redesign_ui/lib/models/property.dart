class Property {
  final String name;
  final String description;
  final String imagePath;
  final String price;

  Property({this.name, this.description, this.imagePath, this.price});
}
