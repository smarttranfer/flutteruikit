import 'package:flutter/material.dart';

class Constants {
  static const Color primaryColor = Color.fromRGBO(224, 177, 121, 1);
}
