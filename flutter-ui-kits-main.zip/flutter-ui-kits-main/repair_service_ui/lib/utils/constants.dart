import 'package:flutter/material.dart';

class Constants {
  static final Color primaryColor = Color.fromRGBO(18, 26, 28, 1);
  static final Color greyColor = Color.fromRGBO(247, 247, 249, 1);
}
