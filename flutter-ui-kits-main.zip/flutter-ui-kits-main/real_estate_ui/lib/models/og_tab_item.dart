class OgTabItem {
  final String title;

  OgTabItem({this.title});
}
