import 'package:flutter/material.dart';

class Constants {
  static const Color primaryColor = Color.fromRGBO(17, 82, 253, 1);
  static const Color blackColor = Color.fromRGBO(38, 42, 46, 1);
}
