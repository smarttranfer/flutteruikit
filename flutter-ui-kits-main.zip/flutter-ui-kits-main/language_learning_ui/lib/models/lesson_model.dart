class LessonModel {
  final String duration;
  final String title;
  final String imagePath;

  LessonModel({this.title, this.imagePath, this.duration});
}
