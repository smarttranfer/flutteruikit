class LanguageModel {
  final String language;
  final String imagePath;

  LanguageModel({this.language, this.imagePath});
}
