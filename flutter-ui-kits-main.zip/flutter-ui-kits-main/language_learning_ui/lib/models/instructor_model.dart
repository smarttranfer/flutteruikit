class InstructorModel {
  final String name;
  final String image;
  final String occupation;

  InstructorModel({this.name, this.image, this.occupation});
}
