import 'package:flutter/material.dart';

class CourseModel {
  final String image;
  final String name;
  final Color color;

  CourseModel({this.image, this.name, this.color});
}
