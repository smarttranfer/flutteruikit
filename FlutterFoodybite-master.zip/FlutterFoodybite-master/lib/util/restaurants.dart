List restaurants = [
  {
    "img": "assets/food1.jpeg",
    "title": "Happy Jones",
    "address": "1278 Loving Acres RoadKansas City, MO 64110",
    "rating": "4.5"
  },
  {
    "img": "assets/food2.jpeg",
    "title": "Uncle Boons",
    "address": "1278 Loving Acres RoadKansas City, MO 64110",
    "rating": "4.5"
  },
  {
    "img": "assets/food3.jpeg",
    "title": "Happy Jones",
    "address": "1278 Loving Acres RoadKansas City, MO 64110",
    "rating": "4.5"
  },
  {
    "img": "assets/food4.jpeg",
    "title": "Uncle Boons",
    "address": "1278 Loving Acres RoadKansas City, MO 64110",
    "rating": "4.5"
  },
  {
    "img": "assets/food5.jpeg",
    "title": "Happy Jones",
    "address": "1278 Loving Acres RoadKansas City, MO 64110",
    "rating": "4.5"
  },
  {
    "img": "assets/food6.jpeg",
    "title": "Happy Jones",
    "address": "1278 Loving Acres RoadKansas City, MO 64110",
    "rating": "4.5"
  },
  {
    "img": "assets/food7.jpeg",
    "title": "Happy Jones",
    "address": "1278 Loving Acres RoadKansas City, MO 64110",
    "rating": "4.5"
  },
  {
    "img": "assets/food8.jpeg",
    "title": "Happy Jones",
    "address": "1278 Loving Acres RoadKansas City, MO 64110",
    "rating": "4.5"
  },
  {
    "img": "assets/food9.jpeg",
    "title": "Happy Jones",
    "address": "1278 Loving Acres RoadKansas City, MO 64110",
    "rating": "4.5"
  }
];
