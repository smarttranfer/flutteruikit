package com.example.flutter_parallax_scroll

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
