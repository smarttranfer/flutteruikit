import 'package:flutter/widgets.dart';

class Consts {
  static Offset svgLayersOffset = Offset(0, -134);
  static Offset svgBackgroundIconsOffst = Offset(0, 914);
  static Offset svgLayer2IconsOffst = Offset(0, 126);
  static Offset svgLayer3IconsOffst = Offset(0, 592);
}
